<?php

	$link=mysqli_connect("localhost","root","","assk") or die("Error: connecting database.".mysqli_connect_error());

?>